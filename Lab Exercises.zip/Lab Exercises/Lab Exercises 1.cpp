#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

void problem_1(){
	
	int i[10];
	
	cout << "Enter 10 numbers: \n";
	for(int a = 1 ; a <= 10; a++){
		
		if(cin.fail()){
			
			
			
			cin.clear();
			cin.ignore(1000, '\n');
			cout << endl;
			a -= 1;	
			system("CLS");
			cout << "\nWrong Input\n";
		}
		cout << a << ": ";
		cin >> i[a];
	}
	
	for(int b = 1; b <= 10; b++){
		
		for(int c = 1; c <= 10-b; c++){
			
			if(i[c] > i[c+1]){
				
				int d = i[c];
				i[c] = i[c+1];
				i[c+1] = d;
			}
		}
	}
	
	cout << "\n Ascending Order\n";
	for(int e = 1; e <=10; e++){
		
		cout << e << ": " << i[e] << endl;
 	}
 	
 	char choice1;
		b:			cout << "\nEnter Y to continue\nEnter N to Exit\n";
			cin >> choice1;
			
			switch(choice1) {
				case 'Y':
					system("CLS");
					problem_1();
					break;
				
				case 'y':
					system("CLS");
					problem_1();
					break;	
				
				case 'N':
					cout << "EXITING......";
					break;
				
				case 'n':
					cout << "EXITING......";
					break;	
					
				default:
					system("CLS");
					cout  << "Wrong Input";
					goto b;
			}
 	
 	
};

void problem_2(){
	
a:	int a[10], n, i;    
	cout<<"Enter the number to convert: ";    
	cin>>n;  
	  
	  
	if(cin.fail()){
			
			cin.clear();
			cin.ignore(1000, '\n');
			system("CLS");
			cout << "\nWrong Input\n";
			goto a;
			
	}
	
	else if (!cin.fail()){
		
		for(i=0; n>0; i++)    
		{    
			a[i]=n%2;    
			n= n/2;  
		}   
		 
		cout<<"Binary of the given number: ";    
	
		for(i=i-1 ;i>=0 ;i--)    
		{    
			cout<<a[i];    
		}    
	}
	
	char choice1;
		b:			cout << "\nEnter Y to continue\nEnter N to Exit\n";
			cin >> choice1;
			
			switch(choice1) {
				case 'Y':
					system("CLS");
					problem_2();
					break;
				
				case 'y':
					system("CLS");
					problem_2();
					break;	
				
				case 'N':
					cout << "EXITING......";
					break;
				
				case 'n':
					cout << "EXITING......";
					break;	
					
				default:
					system("CLS");
					cout  << "Wrong Input";
					goto b;
			}
	
};

void problem_3(){
	
	int i[10];
	
	cout << "Enter 10 numbers: \n";
	for(int a = 1 ; a <= 10; a++){
		
		if(cin.fail()){
			
			
			
			cin.clear();
			cin.ignore(1000, '\n');
			cout << endl;
			a -= 1;	
			system("CLS");
			cout << "\nWrong Input\n";
		}
		cout << a << ": ";
		cin >> i[a];
	}
	
	for(int b = 1; b <= 10; b++){
		
		for(int c = 1; c <= 10-b; c++){
			
			if(i[c] > i[c+1]){
				
				int d = i[c];
				i[c] = i[c+1];
				i[c+1] = d;
			}
		}
	}
	
	cout << "\nfirst to the highest " << i[10] << endl
		 << "second to the highest " << i[9] << endl
		 << "\nfirst to the lowest " << i[1] << endl
		 << "second to the lowest " << i[2];
		 
	char choice1;
		b:			cout << "\nEnter Y to continue\nEnter N to Exit\n";
			cin >> choice1;
			
			switch(choice1) {
				case 'Y':
					system("CLS");
					problem_3();
					break;
				
				case 'y':
					system("CLS");
					problem_3();
					break;	
				
				case 'N':
					cout << "EXITING......";
					break;
				
				case 'n':
					cout << "EXITING......";
					break;	
					
				default:
					system("CLS");
					cout  << "Wrong Input";
					goto b;
			}	 
};

void problem_4(){
	
	string a;
	string b;
	
	cout << "Input a string: ";
	cin >> a;
	
	for(int i = a.size()-1; i >= 0; i--){
		
		b = b + a[i]; 
	}
	
	if(a==b){
		
		cout << a << " is Palindrome";
	}
	else if(a!=b){
		
		cout << a << " is not Palindrome";
	}
	
	char choice1;
		b:			cout << "\nEnter Y to continue\nEnter N to Exit\n";
			cin >> choice1;
			
			switch(choice1) {
				case 'Y':
					system("CLS");
					problem_4();
					break;
				
				case 'y':
					system("CLS");
					problem_4();
					break;	
				
				case 'N':
					cout << "EXITING......";
					break;
				
				case 'n':
					cout << "EXITING......";
					break;	
					
				default:
					system("CLS");
					cout  << "Wrong Input";
					goto b;
			}
};

int main(){
	
	char choose;
	cout << "1. Problem 1\n2. Problem 2\n3. Problem 3\n4. Problem 4\nChoose: ";
	cin >> choose;
	
	switch (choose){
		
		case '1':
			system("CLS");
			problem_1();
			break;
		
		case '2':
			system("CLS");
			problem_2();
			break;
			
		case '3':
			system("CLS");
			problem_3();
			break;
			
		case '4':
			system("CLS");
			problem_4();
			break;
			
		default:
			system("CLS");
			cout << "Wrong Input\n";
			main();	
	}
	
	return 0;
}


