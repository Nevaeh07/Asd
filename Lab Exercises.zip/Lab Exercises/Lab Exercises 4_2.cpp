#include<stdio.h>
#include<ctype.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>

void copy_string(char*, char*);
int compare_string(char*, char*);
void concatenate_string(char*, char*);
int string_length(char*);
void reverse(char*);

main()
{
	char Repeat[0], MenuStorage[0], RepeatFunc[0];
	int MenuError, FuncMode;
	//Repeats the whole program//
	do
	{
		//Clears the window//
		system("cls");
		MenuError = 0;
		//Input Checking Loop//
		do
		{
			//Instructing the user//
			printf("\n\t This program manipulates strings using pointers.");
			printf("\n\t ****************************************************************************");
			printf("\n\t M E N U (Please enter the Number that corresponds to your Desired Function.)");
			printf("\n\t ****************************************************************************");
			printf("\n\t [1] - String copy	");
			printf("\n\t [2] - String compare");
			printf("\n\t [3] - String concatenate");
			printf("\n\t [4] - String length");
			printf("\n\t [5] - String reverse");
			printf("\n\t [6] - E X I T");
			printf("\n\t ****************************************************************************");
			printf("\n\t Please enter the number of your choice	: ");
			gets(MenuStorage);
			FuncMode = atoi(MenuStorage);
			if(FuncMode >= 1 && FuncMode <= 6)
			{
				MenuError = 0;
			}
			else
			{
				MenuError = 1;
				//Clears the window//
				system("cls");
				printf("\n\t ERROR: INVALID INPUT\n\t Please try again. \n");
			}
		}while(MenuError == 1);
		//Clears the window//
		system("cls");
		switch(FuncMode)
		{
			case 1:
				//Repeats the Function//
				do
				{
					//Clears the window//
					system("cls");
					char source[100], target[100];
					printf("\n\t String Copy Selected");
					printf("\n\t Enter source string: ");
					gets(source);
					copy_string(target, source);
					printf("\n\t Target string is \"%s\"\n", target);
					printf("\n\t Do you want to copy string again?");
					printf("\n\t Press Y or y if YES, Press Any key if NO: ");
					gets(RepeatFunc);
				}while(RepeatFunc[0] == 'Y' || RepeatFunc[0] == 'y');
			break;
			
			case 2:
				//Repeats the Function//
				do 
				{
					//Clears the window//
					system("cls");
					char first[100], second[100], result;
	 				printf("\n\t String Compare Selected");
				    printf("\n\t Enter first string: ");
				    gets(first);
				    printf("\n\t Enter second string: ");
				    gets(second);
				    result = compare_string(first, second);
				    if ( result == 0 )
				       printf("\n\t Result: Both strings are same.\n");
				    else
				       printf("\n\t Result: Entered strings are not equal.\n");
				    printf("\n\t Do you want to compare string again?");
					printf("\n\t Press Y or y if YES, Press Any key if NO: ");
					gets(RepeatFunc);
				}while(RepeatFunc[0] == 'Y' || RepeatFunc[0] == 'y');
			break;
			
			case 3:
				//Repeats the Function//
				do
				{
					//Clears the window//
					system("cls");
					char original[100], add[100];
					printf("\n\t String Concatenate Selected");
					printf("\n\t Enter source string: ");
    				gets(original);
    				printf("\n\t Enter string to concatenate: ");
    				gets(add);
					concatenate_string(original, add);
					printf("\n\t String after concatenation: \"%s\"\n", original);
					
					printf("\n\t Do you want to concatenate string again?");
					printf("\n\t Press Y or y if YES, Press Any key if NO: ");
					gets(RepeatFunc);
				}while(RepeatFunc[0] == 'Y' || RepeatFunc[0] == 'y');	
			break;
			
			case 4:
				//Repeats the Function//
				do
				{
					//Clears the window//
					system("cls");
					char str[100], *pt;
					int i = 0;
					printf("\n\t String Length Selected");
					printf("\n\t Enter source string: ");
					gets(str);
					pt = str;
					while (*pt != '\0')
					{
						i++;
						pt++;
					}
					printf("\n\t Length of String : %d", i);
					printf("\n\t Do you want to concatenate string again?");
					printf("\n\t Press Y or y if YES, Press Any key if NO: ");
					gets(RepeatFunc);
				}while(RepeatFunc[0] == 'Y' || RepeatFunc[0] == 'y');	
			break;
			
			case 5:
				//Repeats the Function//
				do
				{
					//Clears the window//
					system("cls");
					char s[100];
					printf("\n\t String Reverse Selected");
					printf("\n\t Enter source string: ");
					gets(s);
					reverse(s);
					printf("\n\t Reverse of the string is \"%s\".\n", s);
					printf("\n\t Do you want to reverse string again?");
					printf("\n\t Press Y or y if YES, Press Any key if NO: ");
					gets(RepeatFunc);
				}while(RepeatFunc[0] == 'Y' || RepeatFunc[0] == 'y');
			break;
			
			case 6:
				printf("\n\t PROCESS TERMINATED!");
				return 0;
			break;
		}
		
		//Asks the user if want to try again//
		printf("\n\t Do you want to try again?");
		printf("\n\t Press Y or y if YES, Press Any key if NO: ");
		gets(Repeat);
	}while(Repeat[0] == 'Y' || Repeat[0] == 'y');
}

void copy_string(char *target, char *source)
{
    while(*source)
    {
        *target = *source;        
        source++;        
        target++;
    }    
    *target = '\0';
}

int compare_string(char *first, char *second)
{
	while(*first==*second)
	{
    	if ( *first == '\0' || *second == '\0' )
			break;
 
		first++;
		second++;
	}
	if( *first == '\0' && *second == '\0' )
		return 0;
	else
    	return -1;
}

void concatenate_string(char *original, char *add)
{
	while(*original)
		original++;
     
	while(*add)
	{
		*original = *add;
		add++;
		original++;
	}
	*original = '\0';
}

int string_length(char *pointer)
{
	int c = 0;
 
	while( *(pointer + c) != '\0' )
		c++;
 
	return c;
}

void reverse(char *s)
{
	int length, c;
	char *begin, *end, temp;
 
	length = string_length(s);
	begin  = s;
	end    = s;
 
	for (c = 0; c < length - 1; c++)
		end++;
 
	for (c = 0; c < length/2; c++)
	{        
		temp   = *end;
		*end   = *begin;
		*begin = temp;
 
		begin++;
		end--;
	}
}
