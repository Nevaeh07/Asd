#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;


void problem_1(){
	
	char choice;
	int side;
	float base, height;
	int length, width;
	float pi = M_PI;
	float r;
	cout << "[1] - Area of square\n[2] - Area of rectangle\n[3] - Area of triangle\n[4] - Area of circle\n[5] - exit"
		 << "\nEnter your choice: ";
		 	 
	cin >> choice;
	
	switch(choice){
		
		case '1':
			
az:			cout << "AREA OF SQUARE\nEnter the side of the square: ";
			cin >> side;
			
			if(side <= 0 ||cin.fail()){
				
				cin.clear();
				cin.ignore(1000, '\n');
				system("CLS");
				cout << "\nWrong Input\n";
				goto az;
				
		}
			cout << "The area is " << side*side << " sq. units";
			char choice1;
a:			cout << "\nEnter Y to continue\nEnter N to Exit\n";
			cin >> choice1;
			
			switch(choice1) {
				case 'Y':
					system("CLS");
					problem_1();
					break;
				
				case 'y':
					system("CLS");
					problem_1();
					break;	
				
				case 'N':
					cout << "EXITING......";
					break;
				
				case 'n':
					cout << "EXITING......";
					break;	
					
				default:
					system("CLS");
					cout  << "Wrong Input";
					goto a;
			}
			break;
		
		case '2':
			
			cout << "AREA OF RECTANGLE";
bz:			cout	 << "\nEnter the length: ";
			cin >> length;
		if(length <= 0 ||cin.fail()){
				
				cin.clear();
				cin.ignore(1000, '\n');
				system("CLS");
				cout << "\nWrong Input\n";
				goto bz;
				
		}	
			
bx:			cout << "Enter the width: ";
			cin >> width;
			
		if(width <= 0 ||cin.fail()){
				
				cin.clear();
				cin.ignore(1000, '\n');
				system("CLS");
				cout << "\nWrong Input\n";
				goto bx;
				
		}	
			cout << "The area is " << length * width << " sq. units";
			char choice2;
b:			cout << "\nEnter Y to continue\nEnter N to Exit\n";
			cin >> choice2;
			
			switch(choice2) {
				case 'Y':
					system("CLS");
					problem_1();
					break;
				
				case 'y':
					system("CLS");
					problem_1();
					break;	
				
				case 'N':
					cout << "EXITING......";
					break;
				
				case 'n':
					cout << "EXITING......";
					break;	
					
				default:
					system("CLS");
					cout  << "Wrong Input";
					goto b;
			}
			break;
			
		case '3':
			
			cout << "AREA OF TRIANGLE";
cz:			cout << "\nEnter the base: ";
			cin >> base;
			
		if(base <= 0 ||cin.fail()){
				
				cin.clear();
				cin.ignore(1000, '\n');
				system("CLS");
				cout << "\nWrong Input\n";
				goto cz;
				
		}	
			
cx:			cout << "Enter the height: ";
			cin >> height;
			
			if(height <= 0 || cin.fail()){
				
				cin.clear();
				cin.ignore(1000, '\n');
				system("CLS");
				cout << "\nWrong Input\n";
				goto cx;
				
		}	
			cout << fixed;
			cout << "The area is " << setprecision(2) << (base*height)/2 << " sq. units";
			char choice3;
c:			cout << "\nEnter Y to continue\nEnter N to Exit\n";
			cin >> choice3;
			
			switch(choice3) {
				case 'Y':
					system("CLS");
					problem_1();
					break;
				
				case 'y':
					system("CLS");
					problem_1();
					break;	
				
				case 'N':
					cout << "EXITING......";
					break;
				
				case 'n':
					cout << "EXITING......";
					break;	
					
				default:
					system("CLS");
					cout  << "Wrong Input";
					goto c;
			}
			break;
			
		case '4':
			
			cout << "AREA OF CIRCLE\n";
dz:			cout << "Enter the radius: ";
			cin >> r;
		
		if(r <= 0 || cin.fail()){
				
				cin.clear();
				cin.ignore(1000, '\n');
				system("CLS");
				cout << "\nWrong Input\n";
				goto dz;
				
		}	
			
			cout << fixed;
			cout << "The area is " << setprecision(2) << r*r*pi << " sq. units";
			char choice4;
d:			cout << "\nEnter Y to continue\nEnter N to Exit\n";
			cin >> choice4;
			
			switch(choice4) {
				case 'Y':
					system("CLS");
					problem_1();
					break;
				
				case 'y':
					system("CLS");
					problem_1();
					break;	
				
				case 'N':
					cout << "EXITING......";
					break;
				
				case 'n':
					cout << "EXITING......";
					break;	
					
				default:
					system("CLS");
					cout  << "Wrong Input";
					goto d;
			}
			break;
		
		case '5':
			system("CLS");
			cout << "EXITING.......";
			break;
		
		default:
			system("CLS");
			cout << "Wrong Input" << endl;
			problem_1();
	}
};

void problem_2(){
	
a:	int factorial;
	int result = 1;
	
	cout << "Enter a number: ";
	cin >> factorial;
	
	if(factorial < 0 || cin.fail()){
			
		cin.clear();
		cin.ignore(1000, '\n');
		system("CLS");
		cout << "\nWrong Input\n";
		goto a;
		
	}
	else if(!cin.fail()){
		
		for(int a = factorial; a>0; a--){
			
			result *= a;
		}
		
		cout << "The factorial of " << factorial << " is " << result;
		
		char choice1;
		b:			cout << "\nEnter Y to continue\nEnter N to Exit\n";
			cin >> choice1;
			
			switch(choice1) {
				case 'Y':
					system("CLS");
					problem_2();
					break;
				
				case 'y':
					system("CLS");
					problem_2();
					break;	
				
				case 'N':
					cout << "EXITING......";
					break;
				
				case 'n':
					cout << "EXITING......";
					break;	
					
				default:
					system("CLS");
					cout  << "Wrong Input";
					goto b;
			}
	}
};

void problem_3(){
	
a:	int first, second;
	cout << "Enter the first number: ";
	cin >> first;
	cout << "Enter the second number: ";
	cin >> second;
	
	if(cin.fail()){
			
			cin.clear();
			cin.ignore(1000, '\n');
			system("CLS");
			cout << "\nWrong Input\n";
			goto a;
			
	}
	else if(!cin.fail()){
		
		if(first > second){
			
			cout << first << " is greater than " << second;
		}
		else if (second > first){
			
			cout << second << " is greater than " << first;
		}
		else if(first == second){
			
			cout << "Both numbers are equal";
		}
		char choice1;
		b:			cout << "\nEnter Y to continue\nEnter N to Exit\n";
			cin >> choice1;
			
			switch(choice1) {
				case 'Y':
					system("CLS");
					problem_3();
					break;
				
				case 'y':
					system("CLS");
					problem_3();
					break;	
				
				case 'N':
					cout << "EXITING......";
					break;
				
				case 'n':
					cout << "EXITING......";
					break;	
					
				default:
					system("CLS");
					cout  << "Wrong Input";
					goto b;
			}	
		
	}
};

void problem_4(){
	
	int array[10][10] = {0};
	int column, row, value;
	
	for(int x=0; x < 10; x++){
		
		array[x][x] = 1;
	}
	
a:	cout << "Enter column number: ";
	cin >> column;
	if(column < 1 || column > 10 || cin.fail()){
		
		cin.clear();
		cin.ignore(1000, '\n');
		system("CLS");
		cout << "Wrong Input\n";
		goto a;
	}
b:	cout << "Enter row number: ";
	cin >> row;
	if(row < 1 || row > 10 || cin.fail()){
		
		cin.clear();
		cin.ignore(1000, '\n');
		system("CLS");
		cout << "Wrong Input\n";
		goto b;
	}
c:	cout << "Enter value: ";
	cin >> value;
	if(cin.fail()){
		
		cin.clear();
		cin.ignore(1000, '\n');
		system("CLS");
		cout << "Wrong Input\n";
		goto c;
	}
	
	array[row-1][column-1] = value;
	
	for(int a = 0; a < 10; a++){
		
		for(int b = 0; b < 10; b++){
			
			cout << array[a][b] << "\t";
		}
		cout << endl;
	}
	char choice1;
f:	cout << "\nEnter Y to continue\nEnter N to Exit\n";
			cin >> choice1;
			
			switch(choice1) {
				case 'Y':
					system("CLS");
					problem_4();
					break;
				
				case 'y':
					system("CLS");
					problem_4();
					break;	
				
				case 'N':
					cout << "EXITING......";
					break;
				
				case 'n':
					cout << "EXITING......";
					break;	
					
				default:
					system("CLS");
					cout  << "Wrong Input";
					goto f;
			}		
}

int main(){
	
	char choose;
	cout << "1. Problem 1\n2. Problem 2\n3. Problem 3\n4. Problem 4\nChoose: ";
	cin >> choose;
	
	switch (choose){
		
		case '1':
			system("CLS");
			problem_1();
			break;
		
		case '2':
			system("CLS");
			problem_2();
			break;
			
		case '3':
			system("CLS");
			problem_3();
			break;
			
		case '4':
			system("CLS");
			problem_4();
			break;
			
		default:
			system("CLS");
			cout << "Wrong Input\n";
			main();	
	}
	
	return 0;
}


