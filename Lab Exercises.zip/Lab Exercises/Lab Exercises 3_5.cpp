#include <iostream>

int main()
{
   const int size = 80;
   
   char sentence[size];
   
   std::cout << "Please enter a sentence.\n";
   std::cin.getline(sentence, size); // make sure limit is not excedded

   sentence[0] = toupper(sentence[0]);
   
   for (int i = 1; i < size; i++)
   {
        if ( sentence[i - 1] == ' ' )
            sentence[i] = toupper( sentence[i] );
        else
            sentence[i] = tolower(sentence[i]);
   }

   std::cout << sentence << std::endl;
   
   return 0;
}

